<?php
class OrderModel {
	public $id;
	public $account;
	public $email;
	public $fname;
	public $lname;
	public $address;
	public $postcode;
	public $city;
	public $phone;
	public $totalPrice;
	public $status;
}
?>