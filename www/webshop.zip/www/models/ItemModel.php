<?php
class ItemModel {
	public $id;
	public $name;
	public $price;
	public $description;
	public $img;
}
?>